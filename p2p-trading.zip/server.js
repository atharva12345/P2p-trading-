
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

// Middleware to parse JSON
app.use(bodyParser.json());

// Serve static files (HTML, CSS, JS)
app.use(express.static('public'));

// Simple route to check if the server is running
app.get('/', (req, res) => {
  res.send('Server is up and running!');
});

// Example route to handle user registration
app.post('/register', (req, res) => {
  const { username, email, password } = req.body;
  // Here you would save the user data to your database (not shown for simplicity)
  res.json({ message: 'Registration successful', user: { username, email } });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
