
document.querySelector('.cta').addEventListener('click', () => {
  alert("Redirecting to sign-up page...");
  // You can redirect the user to the registration page or open a modal here.
});
